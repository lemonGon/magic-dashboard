-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 20, 2018 at 11:13 AM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dashboard`
--

-- --------------------------------------------------------

--
-- Table structure for table `app_country`
--

CREATE TABLE `app_country` (
  `id` smallint(5) UNSIGNED NOT NULL,
  `name` varchar(127) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `app_country`
--

INSERT INTO `app_country` (`id`, `name`) VALUES
(1, 'Ireland'),
(2, 'Denmark');

-- --------------------------------------------------------

--
-- Table structure for table `app_customer`
--

CREATE TABLE `app_customer` (
  `id` int(10) UNSIGNED NOT NULL,
  `email_domain_id` mediumint(8) UNSIGNED NOT NULL,
  `first_name` varchar(65) NOT NULL,
  `last_name` varchar(65) NOT NULL,
  `email_local` varchar(64) NOT NULL,
  `reg_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `app_customer`
--

INSERT INTO `app_customer` (`id`, `email_domain_id`, `first_name`, `last_name`, `email_local`, `reg_date`) VALUES
(1, 1, 'Roberto', 'Rizzi', 'roberto.rizzi87', '2018-03-13 11:41:22'),
(4, 2, 'Luca', 'Rossi', 'luca.rossi', '2018-03-07 15:28:33'),
(5, 4, 'Jesper', 'Brøndum', 'jesper.brondum', '2018-03-02 09:34:30'),
(6, 4, 'Aurelijus', 'Valeiša', 'aurelijus.valeisa', '2018-02-22 05:09:18'),
(7, 1, 'Fancy', 'User', 'fancy.user', '2018-02-01 10:11:22'),
(8, 2, 'April', 'Fish', 'april.fish', '2017-04-01 01:43:02'),
(9, 2, 'Lucky', 'Guy', 'lucky.guy', '2018-03-13 03:14:10'),
(10, 4, 'Roberto', 'Rizzi', 'roberto.rizzi', '2018-03-13 23:27:14'),
(11, 1, 'Denmark', 'Ilikeyou', 'denmark.ilikeyou', '2018-03-07 01:02:03'),
(12, 1, 'Giorgio', 'Armani', 'giorgio.armani', '2018-03-02 22:14:21'),
(13, 2, 'Dolce', 'Gabbana', 'dolce.gabbana', '2018-03-02 20:23:45'),
(14, 2, 'Yves', 'Saint Laurent', 'yves.saint.laurent', '2018-03-02 12:14:23'),
(15, 1, 'Alberta', 'Ferretti', 'alberta.ferretti', '2018-03-07 01:02:01'),
(16, 1, 'Wang', 'Wang', 'alexander.wang', '2018-03-07 04:03:01');

-- --------------------------------------------------------

--
-- Table structure for table `app_email_domain`
--

CREATE TABLE `app_email_domain` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `email_domain` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `app_email_domain`
--

INSERT INTO `app_email_domain` (`id`, `email_domain`) VALUES
(1, 'gmail.com'),
(2, 'hotmail.com'),
(4, 'boozt.com');

-- --------------------------------------------------------

--
-- Table structure for table `app_item`
--

CREATE TABLE `app_item` (
  `id` int(10) UNSIGNED NOT NULL,
  `ean` char(13) NOT NULL,
  `qnt` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `price` decimal(7,2) UNSIGNED NOT NULL DEFAULT '0.00',
  `is_active` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `name` varchar(127) NOT NULL,
  `description` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `app_item`
--

INSERT INTO `app_item` (`id`, `ean`, `qnt`, `price`, `is_active`, `name`, `description`) VALUES
(1, '0123456789123', 2, '79.50', 1, 'Noa Noa', NULL),
(2, '219876543210', 1, '139.95', 1, 'SamsØe & SamsØe', 'Cybill pants'),
(3, '7463920355656', 5, '100.00', 1, 'DEEP V-NECK SWEAT', NULL),
(4, '333444556677', 0, '128.00', 1, 'Dot camisole', NULL),
(5, '2589635789654', 0, '225.00', 1, 'O2. SAILORS DRESS ', NULL),
(6, '0974623560193', 3, '26100.00', 1, 'YGRE PARKA - SPORTS JACKETS', NULL),
(7, '1224556700125', 0, '7499.00', 1, 'Kaka Coat ', NULL),
(8, '958241865774', 0, '1561.00', 1, 'Trent', NULL),
(9, '', 3, '1000.00', 1, 'Tapered leg lurex striped pants', NULL),
(10, '5589637347455', 9, '3749.00', 1, 'BACK FLIP PANT', NULL),
(11, '234351112098', 3, '2436.00', 1, 'Taylor', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `app_order`
--

CREATE TABLE `app_order` (
  `id` int(10) UNSIGNED NOT NULL,
  `customer_id` int(10) UNSIGNED NOT NULL,
  `country_id` smallint(5) UNSIGNED NOT NULL,
  `device` varchar(127) NOT NULL,
  `purchase_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `app_order`
--

INSERT INTO `app_order` (`id`, `customer_id`, `country_id`, `device`, `purchase_date`) VALUES
(1, 6, 2, 'Nokia 33.10 :)', '2018-02-20 03:10:18'),
(2, 6, 2, 'Nokia 33.10 :)', '2018-02-21 09:10:15'),
(8, 8, 1, 'IPhone 20', '2018-03-08 18:21:14'),
(9, 5, 2, 'Iphone 8 plus', '2018-03-04 22:07:12'),
(10, 5, 2, 'Iphone 8 plus', '2018-03-13 18:13:15'),
(11, 4, 1, 'OnePlus One', '2018-03-10 23:08:13'),
(12, 1, 1, 'OnePlus One', '2018-03-13 17:58:29'),
(13, 1, 1, 'OnePlus One', '2017-11-08 05:07:08'),
(14, 6, 2, 'Nokia 33.10 :)', '2017-05-05 21:07:09'),
(15, 6, 2, 'dunno', '2017-05-05 07:26:27'),
(16, 6, 2, 'Nokia N-Gage', '2018-03-13 10:50:15'),
(17, 4, 1, 'Siemens C35', '2018-03-13 04:14:21'),
(18, 11, 2, 'Telit', '2018-03-10 08:11:17'),
(19, 11, 2, 'Telit', '2018-03-10 07:14:18'),
(20, 5, 2, 'I-Phone 10X', '2018-03-08 05:13:10');

-- --------------------------------------------------------

--
-- Table structure for table `app_order_item_rel`
--

CREATE TABLE `app_order_item_rel` (
  `order_id` int(10) UNSIGNED NOT NULL,
  `item_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `app_order_item_rel`
--

INSERT INTO `app_order_item_rel` (`order_id`, `item_id`) VALUES
(1, 1),
(1, 3),
(1, 6),
(1, 7),
(1, 11),
(2, 5),
(2, 8),
(2, 9),
(8, 1),
(8, 4),
(8, 5),
(9, 1),
(9, 2),
(9, 3),
(9, 6),
(9, 11),
(10, 2),
(11, 5),
(12, 1),
(12, 5),
(13, 1),
(14, 4),
(15, 5),
(16, 6),
(16, 10),
(16, 11),
(18, 7),
(18, 8),
(19, 6),
(20, 1),
(20, 6),
(20, 7);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `app_country`
--
ALTER TABLE `app_country`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_customer`
--
ALTER TABLE `app_customer`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_app_customer_app_email_domain_idx` (`email_domain_id`) USING BTREE;

--
-- Indexes for table `app_email_domain`
--
ALTER TABLE `app_email_domain`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_item`
--
ALTER TABLE `app_item`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `EAN_UNIQUE` (`ean`);

--
-- Indexes for table `app_order`
--
ALTER TABLE `app_order`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_app_order_app_customer_idx` (`customer_id`) USING BTREE,
  ADD KEY `fk_app_order_app_country_idx` (`country_id`) USING BTREE;

--
-- Indexes for table `app_order_item_rel`
--
ALTER TABLE `app_order_item_rel`
  ADD PRIMARY KEY (`order_id`,`item_id`),
  ADD KEY `fk_app_order_ite_rel_app_order_idx` (`order_id`) USING BTREE,
  ADD KEY `fk_app_order_ite_rel_app_item_idx` (`item_id`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `app_country`
--
ALTER TABLE `app_country`
  MODIFY `id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `app_customer`
--
ALTER TABLE `app_customer`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `app_email_domain`
--
ALTER TABLE `app_email_domain`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `app_item`
--
ALTER TABLE `app_item`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `app_order`
--
ALTER TABLE `app_order`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `app_customer`
--
ALTER TABLE `app_customer`
  ADD CONSTRAINT `fk_app_customer_app_email_domain1` FOREIGN KEY (`email_domain_id`) REFERENCES `app_email_domain` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `app_order`
--
ALTER TABLE `app_order`
  ADD CONSTRAINT `fk_app_order_app_country` FOREIGN KEY (`country_id`) REFERENCES `app_country` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_app_order_app_customer` FOREIGN KEY (`customer_id`) REFERENCES `app_customer` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `app_order_item_rel`
--
ALTER TABLE `app_order_item_rel`
  ADD CONSTRAINT `fk_app_order_ite_rel_app_item` FOREIGN KEY (`item_id`) REFERENCES `app_item` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_app_order_ite_rel_app_order` FOREIGN KEY (`order_id`) REFERENCES `app_order` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
